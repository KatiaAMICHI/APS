./../syntaxe/toProlog $1| swipl -s typage.pl -g main_stdin
